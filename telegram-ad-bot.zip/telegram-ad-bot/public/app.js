// public/app.js
const tg = window.Telegram.WebApp;
tg.expand();
tg.ready();

const $balance = document.getElementById('balance');
const $watchBtn = document.getElementById('watchBtn');
const $timer = document.getElementById('timer');
const $status = document.getElementById('status');

const HEARTBEAT_INTERVAL_MS = 5000; // must match server HEARTBEAT_INTERVAL_SECONDS

// ---------------------------------------------------------------------------
// Lightweight device fingerprint.
// NOTE: this raises the cost of multi-accounting but is not unbeatable — a
// determined attacker can spoof canvas output or use a different browser
// profile per account. It should be treated as ONE signal among several
// (combined server-side with IP-based checks), not a silver bullet.
// For stronger fingerprinting, consider integrating a dedicated library
// like FingerprintJS Pro on the client instead of this hand-rolled version.
// ---------------------------------------------------------------------------
async function computeDeviceHash() {
  const parts = [];
  parts.push(navigator.userAgent);
  parts.push(navigator.language);
  parts.push(String(screen.width) + 'x' + String(screen.height));
  parts.push(String(screen.colorDepth));
  parts.push(String(new Date().getTimezoneOffset()));
  parts.push(String(navigator.hardwareConcurrency || ''));

  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('fp-seed-🔒', 2, 2);
    parts.push(canvas.toDataURL());
  } catch (e) {
    parts.push('no-canvas');
  }

  const encoder = new TextEncoder();
  const data = encoder.encode(parts.join('||'));
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(hashBuffer)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function apiFetch(url, options = {}) {
  return fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'x-telegram-init-data': tg.initData,
      ...(options.headers || {}),
    },
  }).then(async (r) => {
    const body = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(body.error || 'request_failed'), { body });
    return body;
  });
}

function setStatus(msg, type) {
  $status.textContent = msg;
  $status.className = 'status' + (type ? ' ' + type : '');
}

function renderBalance(balance) {
  $balance.textContent = '$' + Number(balance).toFixed(4);
}

async function init() {
  try {
    const deviceHash = await computeDeviceHash();
    const { user } = await apiFetch('/api/register', {
      method: 'POST',
      body: JSON.stringify({ deviceHash }),
    });
    renderBalance(user.balance);
    if (user.isBanned) {
      $watchBtn.disabled = true;
      setStatus('Your account has been restricted.', 'error');
    }
  } catch (err) {
    setStatus('Could not start session: ' + (err.body?.reason || err.message), 'error');
    $watchBtn.disabled = true;
  }
}

async function watchAd() {
  $watchBtn.disabled = true;
  setStatus('Loading ad…');

  let session;
  try {
    session = await apiFetch('/api/ad/start', { method: 'POST', body: JSON.stringify({ adUnitId: 'rewarded_1' }) });
  } catch (err) {
    setStatus('Could not start ad: ' + (err.body?.reason || err.message), 'error');
    $watchBtn.disabled = false;
    return;
  }

  // --- Plug your real ad network SDK's rewarded-ad call here instead of
  // this countdown (e.g. Adsgram, Monetag, etc). The server-side timer
  // below is what actually protects you — the visual countdown is just UX. ---

  const totalSeconds = session.requiredSeconds;
  let remaining = totalSeconds;
  $timer.textContent = `⏳ ${remaining}s`;

  const heartbeatTimer = setInterval(() => {
    apiFetch('/api/ad/heartbeat', {
      method: 'POST',
      body: JSON.stringify({ sessionToken: session.sessionToken }),
    }).catch(() => {}); // heartbeat failures are non-fatal to UX; server just won't count them
  }, HEARTBEAT_INTERVAL_MS);

  const countdown = setInterval(async () => {
    remaining -= 1;
    $timer.textContent = remaining > 0 ? `⏳ ${remaining}s` : 'Verifying…';

    if (remaining <= 0) {
      clearInterval(countdown);
      clearInterval(heartbeatTimer);

      try {
        const result = await apiFetch('/api/ad/verify', {
          method: 'POST',
          body: JSON.stringify({ sessionToken: session.sessionToken }),
        });
        renderBalance(result.newBalance);
        setStatus(`+$${result.rewardAmount.toFixed(4)} credited!`, 'success');
      } catch (err) {
        setStatus('Verification failed: ' + (err.body?.reason || err.message), 'error');
      } finally {
        $timer.textContent = '';
        $watchBtn.disabled = false;
      }
    }
  }, 1000);
}

$watchBtn.addEventListener('click', watchAd);
init();
