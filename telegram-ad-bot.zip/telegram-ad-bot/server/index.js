// server/index.js
require('dotenv').config();

const express = require('express');
const path = require('path');
const db = require('./db');
const { requireTelegramAuth } = require('./auth');
const fraud = require('./fraud');
const adTimer = require('./adTimer');
const referral = require('./referral');
const payout = require('./payout');
const { createBot } = require('./bot');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const REWARD_PER_AD = parseFloat(process.env.REWARD_PER_AD || '0.01');
const AD_REQUIRED_SECONDS = parseInt(process.env.AD_REQUIRED_SECONDS || '30', 10);

// Every protected route requires a verified Telegram initData header,
// so req.telegramUser.id is always trustworthy from here on.
const authed = [requireTelegramAuth];

function banGuard(req, res, next) {
  if (fraud.isBanned(String(req.telegramUser.id))) {
    return res.status(403).json({ error: 'account_banned' });
  }
  next();
}

// ---------------------------------------------------------------------------
// POST /api/register
// Called once when the Mini App first loads. Creates the user row (if new),
// runs duplicate-account checks, and resolves any pending referral.
// Body: { deviceHash: string }
// ---------------------------------------------------------------------------
app.post('/api/register', ...authed, (req, res) => {
  const telegramId = String(req.telegramUser.id);
  const { deviceHash } = req.body;
  const ip = fraud.getClientIp(req);

  const existing = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(telegramId);

  if (existing) {
    if (existing.is_banned) return res.status(403).json({ error: 'account_banned', reason: existing.ban_reason });
    return res.json({ ok: true, user: sanitizeUser(existing) });
  }

  const dupCheck = fraud.checkDuplicateAccount({ telegramId, deviceHash, ip });
  if (!dupCheck.allowed) {
    return res.status(403).json({ error: 'registration_blocked', reason: dupCheck.reason });
  }

  db.prepare(`
    INSERT INTO users (telegram_id, username, first_name, device_hash, last_ip)
    VALUES (?, ?, ?, ?, ?)
  `).run(telegramId, req.telegramUser.username || null, req.telegramUser.first_name || null, deviceHash, ip);

  fraud.recordFingerprint({ telegramId, deviceHash, ip });

  // Resolve a pending referral captured by the bot's /start handler, if any.
  const pending = db.prepare(`SELECT * FROM pending_referrals WHERE telegram_id = ?`).get(telegramId);
  if (pending) {
    const referrer = db.prepare(`SELECT device_hash, last_ip FROM users WHERE telegram_id = ?`).get(pending.referrer_id);
    referral.createPendingReferral({
      referrerId: pending.referrer_id,
      referredId: telegramId,
      referrerDeviceHash: referrer?.device_hash,
      referrerIp: referrer?.last_ip,
      referredDeviceHash: deviceHash,
      referredIp: ip,
    });
    db.prepare(`DELETE FROM pending_referrals WHERE telegram_id = ?`).run(telegramId);
  }

  const user = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(telegramId);
  res.json({ ok: true, user: sanitizeUser(user) });
});

// ---------------------------------------------------------------------------
// GET /api/me — current balance/status
// ---------------------------------------------------------------------------
app.get('/api/me', ...authed, (req, res) => {
  const user = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(String(req.telegramUser.id));
  if (!user) return res.status(404).json({ error: 'not_registered' });
  res.json({ user: sanitizeUser(user) });
});

// ---------------------------------------------------------------------------
// POST /api/ad/start — begin a server-timed ad session
// ---------------------------------------------------------------------------
app.post('/api/ad/start', ...authed, banGuard, (req, res) => {
  const telegramId = String(req.telegramUser.id);
  const ip = fraud.getClientIp(req);
  const { adUnitId } = req.body;

  const session = adTimer.startSession({
    telegramId,
    adUnitId,
    requiredSeconds: AD_REQUIRED_SECONDS,
    ip,
  });

  res.json({ ok: true, ...session });
});

// ---------------------------------------------------------------------------
// POST /api/ad/heartbeat — periodic "still watching" ping
// ---------------------------------------------------------------------------
app.post('/api/ad/heartbeat', ...authed, banGuard, (req, res) => {
  const telegramId = String(req.telegramUser.id);
  const { sessionToken } = req.body;
  const result = adTimer.heartbeat({ telegramId, sessionToken });
  res.json(result);
});

// ---------------------------------------------------------------------------
// POST /api/ad/verify — server checks elapsed time & heartbeats, credits balance
// ---------------------------------------------------------------------------
app.post('/api/ad/verify', ...authed, banGuard, (req, res) => {
  const telegramId = String(req.telegramUser.id);
  const { sessionToken } = req.body;

  const result = adTimer.verifySession({ telegramId, sessionToken, rewardAmount: REWARD_PER_AD });

  if (!result.ok) {
    const status = result.reason === 'session_not_found' ? 404 : 400;
    return res.status(status).json(result);
  }

  const refResult = referral.maybeCompleteReferral(telegramId);
  res.json({ ...result, referral: refResult });
});

// ---------------------------------------------------------------------------
// POST /api/withdraw — request a payout
// ---------------------------------------------------------------------------
app.post('/api/withdraw', ...authed, banGuard, (req, res) => {
  const telegramId = String(req.telegramUser.id);
  const { amount, method, accountDetails } = req.body;

  if (!amount || !method || !accountDetails) {
    return res.status(400).json({ error: 'missing_fields' });
  }

  const result = payout.requestWithdrawal({ telegramId, amount: parseFloat(amount), method, accountDetails });
  res.json(result);
});

function sanitizeUser(u) {
  return {
    telegramId: u.telegram_id,
    balance: u.balance,
    isBanned: !!u.is_banned,
  };
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`API listening on port ${PORT}`);
  createBot();
  console.log('Telegram bot polling started');
});
