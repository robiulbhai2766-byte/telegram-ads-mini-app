// server/auth.js
//
// Verifies Telegram Mini App `initData` using the official HMAC-SHA256 scheme.
// This is the single most important security control in the whole app:
// every API call must prove it really came from Telegram, signed with YOUR
// bot token, not just a client claiming to be user X.
//
// Reference: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app

const crypto = require('crypto');

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  throw new Error('BOT_TOKEN is not set in environment');
}

// initData is valid for this long after Telegram issues it (seconds).
const MAX_INIT_DATA_AGE_SECONDS = 24 * 60 * 60; // 24h

function verifyInitData(initData) {
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash) return { valid: false, reason: 'missing_hash' };

  params.delete('hash');

  // Build the data-check-string: all fields sorted alphabetically, "key=value" joined by \n
  const dataCheckArr = [];
  for (const [key, value] of [...params.entries()].sort(([a], [b]) => a.localeCompare(b))) {
    dataCheckArr.push(`${key}=${value}`);
  }
  const dataCheckString = dataCheckArr.join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
  const computedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

  if (computedHash !== hash) {
    return { valid: false, reason: 'bad_signature' };
  }

  const authDate = parseInt(params.get('auth_date') || '0', 10);
  const ageSeconds = Math.floor(Date.now() / 1000) - authDate;
  if (ageSeconds > MAX_INIT_DATA_AGE_SECONDS) {
    return { valid: false, reason: 'expired' };
  }

  let user;
  try {
    user = JSON.parse(params.get('user') || '{}');
  } catch {
    return { valid: false, reason: 'bad_user_payload' };
  }
  if (!user.id) return { valid: false, reason: 'no_user_id' };

  return { valid: true, user, authDate };
}

// Express middleware: expects raw initData string in header `x-telegram-init-data`.
// On success attaches `req.telegramUser` = { id, username, first_name, ... }
function requireTelegramAuth(req, res, next) {
  const initData = req.headers['x-telegram-init-data'];
  if (!initData) {
    return res.status(401).json({ error: 'missing_init_data' });
  }
  const result = verifyInitData(initData);
  if (!result.valid) {
    return res.status(401).json({ error: 'invalid_init_data', reason: result.reason });
  }
  req.telegramUser = result.user;
  next();
}

module.exports = { verifyInitData, requireTelegramAuth };
