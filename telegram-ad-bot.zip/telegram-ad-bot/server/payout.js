// server/payout.js
// Balance is only ever debited inside a DB transaction alongside the
// withdrawal record, so a crash mid-request can't create free money or
// silently swallow a debit.

const db = require('./db');

const MIN_WITHDRAWAL = parseFloat(process.env.MIN_WITHDRAWAL || '1.00');

function requestWithdrawal({ telegramId, amount, method, accountDetails }) {
  if (amount < MIN_WITHDRAWAL) {
    return { ok: false, reason: 'below_minimum', minimum: MIN_WITHDRAWAL };
  }

  const user = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(telegramId);
  if (!user) return { ok: false, reason: 'user_not_found' };
  if (user.is_banned) return { ok: false, reason: 'account_banned' };
  if (user.balance < amount) return { ok: false, reason: 'insufficient_balance', balance: user.balance };

  const tx = db.transaction(() => {
    const newBalance = user.balance - amount;
    db.prepare(`UPDATE users SET balance = ?, updated_at = datetime('now') WHERE telegram_id = ?`)
      .run(newBalance, telegramId);

    const info = db.prepare(`
      INSERT INTO withdrawals (telegram_id, amount, method, account_details, status)
      VALUES (?, ?, ?, ?, 'pending')
    `).run(telegramId, amount, method, accountDetails);

    db.prepare(`
      INSERT INTO transactions (telegram_id, type, amount, balance_after, meta)
      VALUES (?, 'withdrawal', ?, ?, ?)
    `).run(telegramId, -amount, newBalance, JSON.stringify({ withdrawalId: info.lastInsertRowid }));

    return { withdrawalId: info.lastInsertRowid, newBalance };
  });

  const result = tx();
  return { ok: true, ...result };
}

// --- Admin actions (call these from a protected admin panel/CLI, never
// exposed to end users) ---

function approveWithdrawal(withdrawalId, adminNote) {
  db.prepare(`
    UPDATE withdrawals SET status = 'approved', admin_note = ?, processed_at = datetime('now')
    WHERE id = ? AND status = 'pending'
  `).run(adminNote || null, withdrawalId);
}

function markPaid(withdrawalId) {
  db.prepare(`
    UPDATE withdrawals SET status = 'paid', processed_at = datetime('now')
    WHERE id = ? AND status IN ('pending', 'approved')
  `).run(withdrawalId);
}

// Rejecting refunds the balance back to the user.
function rejectWithdrawal(withdrawalId, adminNote) {
  const w = db.prepare(`SELECT * FROM withdrawals WHERE id = ? AND status = 'pending'`).get(withdrawalId);
  if (!w) return { ok: false, reason: 'not_found_or_processed' };

  const tx = db.transaction(() => {
    const user = db.prepare(`SELECT balance FROM users WHERE telegram_id = ?`).get(w.telegram_id);
    const newBalance = user.balance + w.amount;

    db.prepare(`UPDATE users SET balance = ?, updated_at = datetime('now') WHERE telegram_id = ?`)
      .run(newBalance, w.telegram_id);

    db.prepare(`
      UPDATE withdrawals SET status = 'rejected', admin_note = ?, processed_at = datetime('now') WHERE id = ?
    `).run(adminNote || null, withdrawalId);

    db.prepare(`
      INSERT INTO transactions (telegram_id, type, amount, balance_after, meta)
      VALUES (?, 'adjustment', ?, ?, ?)
    `).run(w.telegram_id, w.amount, newBalance, JSON.stringify({ refundForWithdrawal: withdrawalId }));
  });

  tx();
  return { ok: true };
}

module.exports = { requestWithdrawal, approveWithdrawal, markPaid, rejectWithdrawal };
