// server/bot.js
//
// Handles `/start ref_<telegram_id>` deep links. Telegram referral links look
// like: https://t.me/YourBot?start=ref_123456789
//
// We can't attach the referral to a user record yet, because at this point
// we only know their Telegram ID from the bot API — the Mini App hasn't
// opened and authenticated yet. So we stash it in `pending_referrals` and
// consume it during /api/register (see index.js), which is the point where
// we have a verified initData and can safely create the DB relationship.

const TelegramBot = require('node-telegram-bot-api');
const db = require('./db');

function createBot() {
  const token = process.env.BOT_TOKEN;
  const webAppUrl = process.env.WEBAPP_URL;

  const bot = new TelegramBot(token, { polling: true });

  bot.onText(/\/start(?:\s+(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const telegramId = String(msg.from.id);
    const payload = match && match[1];

    if (payload && payload.startsWith('ref_')) {
      const referrerId = payload.slice(4);

      if (referrerId !== telegramId) {
        db.prepare(`
          INSERT INTO pending_referrals (telegram_id, referrer_id)
          VALUES (?, ?)
          ON CONFLICT(telegram_id) DO UPDATE SET referrer_id = excluded.referrer_id
        `).run(telegramId, referrerId);
      }
    }

    bot.sendMessage(chatId, 'Welcome! Tap the button below to start earning.', {
      reply_markup: {
        inline_keyboard: [[{ text: '💰 Open Earning App', web_app: { url: webAppUrl } }]],
      },
    });
  });

  bot.onText(/\/balance/, (msg) => {
    const telegramId = String(msg.from.id);
    const user = db.prepare(`SELECT balance FROM users WHERE telegram_id = ?`).get(telegramId);
    bot.sendMessage(msg.chat.id, user ? `Your balance: $${user.balance.toFixed(4)}` : 'Open the app first to create your account.');
  });

  bot.on('polling_error', (err) => console.error('[bot] polling_error', err.message));

  return bot;
}

module.exports = { createBot };
