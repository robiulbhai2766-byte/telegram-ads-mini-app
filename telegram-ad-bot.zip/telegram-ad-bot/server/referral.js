// server/referral.js
//
// Anti-fake-referral strategy:
//  - A referral is only created as 'pending' at signup — no money moves yet.
//  - It only flips to 'completed' (and pays the referrer) once the REFERRED
//    user has genuinely verified at least one full ad-watch (proof of a real,
//    active human, not just an account that opened once).
//  - We reject the referral outright if the referred account shares a device
//    fingerprint or IP with the referrer (the classic "refer yourself with a
//    second phone number" pattern).
//  - A telegram_id can only ever be `referred_id` once (UNIQUE constraint),
//    so the same user can't be "referred" repeatedly to farm bonuses.

const db = require('./db');

const REFERRAL_BONUS = parseFloat(process.env.REFERRAL_BONUS || '0.05');

/**
 * Call this when a new user completes registration and had a referrer.
 */
function createPendingReferral({ referrerId, referredId, referrerDeviceHash, referrerIp, referredDeviceHash, referredIp }) {
  if (referrerId === referredId) {
    return { ok: false, reason: 'self_referral' };
  }

  const referrer = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(referrerId);
  if (!referrer || referrer.is_banned) {
    return { ok: false, reason: 'referrer_invalid_or_banned' };
  }

  // Same device or same IP as the referrer -> almost certainly the same person.
  if (referrerDeviceHash && referrerDeviceHash === referredDeviceHash) {
    return { ok: false, reason: 'same_device_as_referrer' };
  }
  if (referrerIp && referrerIp === referredIp) {
    return { ok: false, reason: 'same_ip_as_referrer' };
  }

  const existing = db.prepare(`SELECT 1 FROM referrals WHERE referred_id = ?`).get(referredId);
  if (existing) {
    return { ok: false, reason: 'already_referred' };
  }

  db.prepare(`
    INSERT INTO referrals (referrer_id, referred_id, status, reward_amount)
    VALUES (?, ?, 'pending', ?)
  `).run(referrerId, referredId, REFERRAL_BONUS);

  return { ok: true };
}

/**
 * Call this every time a user successfully verifies an ad session
 * (see adTimer.verifySession). If they have a pending referral and this
 * is their first verified ad ever, pay out the referrer now.
 */
function maybeCompleteReferral(referredId) {
  const referral = db.prepare(`SELECT * FROM referrals WHERE referred_id = ? AND status = 'pending'`).get(referredId);
  if (!referral) return { completed: false };

  const verifiedAdCount = db.prepare(`
    SELECT COUNT(*) as cnt FROM ad_sessions WHERE telegram_id = ? AND status = 'verified'
  `).get(referredId).cnt;

  // Require the *first* verified ad as proof of genuine engagement.
  if (verifiedAdCount < 1) return { completed: false };

  const referrer = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(referral.referrer_id);
  if (!referrer || referrer.is_banned) {
    db.prepare(`UPDATE referrals SET status = 'rejected' WHERE id = ?`).run(referral.id);
    return { completed: false, reason: 'referrer_banned' };
  }

  const payTx = db.transaction(() => {
    const newBalance = referrer.balance + referral.reward_amount;
    db.prepare(`UPDATE users SET balance = ?, updated_at = datetime('now') WHERE telegram_id = ?`)
      .run(newBalance, referrer.telegram_id);

    db.prepare(`
      INSERT INTO transactions (telegram_id, type, amount, balance_after, meta)
      VALUES (?, 'referral_bonus', ?, ?, ?)
    `).run(referrer.telegram_id, referral.reward_amount, newBalance, JSON.stringify({ referredId }));

    db.prepare(`UPDATE referrals SET status = 'completed', completed_at = datetime('now') WHERE id = ?`)
      .run(referral.id);
  });

  payTx();
  return { completed: true, referrerId: referrer.telegram_id, amount: referral.reward_amount };
}

module.exports = { createPendingReferral, maybeCompleteReferral };
