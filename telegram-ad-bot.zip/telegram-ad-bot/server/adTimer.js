// server/adTimer.js
//
// The golden rule: NEVER trust a client-reported "I watched the ad" claim.
// The server is the only clock that matters.
//
// Flow:
//   1. Client asks to start an ad -> server creates a session row with
//      started_at = server's own clock, and a random one-time session_token.
//   2. While the "ad" plays, the client pings /api/ad/heartbeat every few
//      seconds. This isn't for timing (we don't trust it for that) — it's
//      a cheap signal that a page was actually open and executing JS,
//      which auto-clickers that just fire the verify request instantly
//      won't produce.
//   3. Client calls /api/ad/verify. Server re-reads started_at from its OWN
//      database, computes elapsed = now - started_at, and rejects if the
//      elapsed time is less than required_seconds OR if heartbeat_count is
//      implausibly low for that elapsed time.
//   4. Session tokens are single-use (status flips to 'verified' or
//      'rejected' and can never be reused).

const crypto = require('crypto');
const db = require('./db');
const fraud = require('./fraud');

const HEARTBEAT_INTERVAL_SECONDS = parseInt(process.env.HEARTBEAT_INTERVAL_SECONDS || '5', 10);
// Allow some slack (network jitter, tab throttling) — require at least
// 60% of the expected heartbeat count rather than 100%.
const HEARTBEAT_TOLERANCE = 0.6;

// Sessions older than this are considered abandoned/expired, not verifiable.
const SESSION_MAX_AGE_SECONDS = 15 * 60;

function startSession({ telegramId, adUnitId, requiredSeconds, ip }) {
  const token = crypto.randomBytes(24).toString('hex');
  db.prepare(`
    INSERT INTO ad_sessions (telegram_id, session_token, ad_unit_id, required_seconds, ip_address)
    VALUES (?, ?, ?, ?, ?)
  `).run(telegramId, token, adUnitId || null, requiredSeconds, ip);

  return { sessionToken: token, requiredSeconds };
}

function heartbeat({ telegramId, sessionToken }) {
  const session = db.prepare(`
    SELECT * FROM ad_sessions WHERE session_token = ? AND telegram_id = ?
  `).get(sessionToken, telegramId);

  if (!session || session.status !== 'pending') {
    return { ok: false, reason: 'invalid_session' };
  }

  db.prepare(`
    UPDATE ad_sessions SET heartbeat_count = heartbeat_count + 1, last_heartbeat_at = datetime('now')
    WHERE id = ?
  `).run(session.id);

  return { ok: true };
}

/**
 * Verifies and, on success, credits the user's balance atomically.
 */
function verifySession({ telegramId, sessionToken, rewardAmount }) {
  const session = db.prepare(`
    SELECT * FROM ad_sessions WHERE session_token = ? AND telegram_id = ?
  `).get(sessionToken, telegramId);

  if (!session) return { ok: false, reason: 'session_not_found' };
  if (session.status !== 'pending') return { ok: false, reason: 'session_already_used' };

  const startedAtMs = new Date(session.started_at + 'Z').getTime();
  const nowMs = Date.now();
  const elapsedSeconds = (nowMs - startedAtMs) / 1000;

  // Too old — likely abandoned, not a fraud signal by itself.
  if (elapsedSeconds > SESSION_MAX_AGE_SECONDS) {
    db.prepare(`UPDATE ad_sessions SET status = 'expired' WHERE id = ?`).run(session.id);
    return { ok: false, reason: 'session_expired' };
  }

  // *** The core anti-cheat check ***
  if (elapsedSeconds < session.required_seconds) {
    db.prepare(`UPDATE ad_sessions SET status = 'rejected' WHERE id = ?`).run(session.id);
    const strike = fraud.markSuspicious(telegramId, 'ad_verified_before_timer_elapsed');
    return { ok: false, reason: 'timer_not_elapsed', strike };
  }

  // *** Heartbeat plausibility check (catches instant/auto-verify bots that
  // never actually render the page) ***
  const expectedHeartbeats = Math.floor(session.required_seconds / HEARTBEAT_INTERVAL_SECONDS);
  const minAcceptable = Math.floor(expectedHeartbeats * HEARTBEAT_TOLERANCE);
  if (expectedHeartbeats > 0 && session.heartbeat_count < minAcceptable) {
    db.prepare(`UPDATE ad_sessions SET status = 'rejected' WHERE id = ?`).run(session.id);
    const strike = fraud.markSuspicious(telegramId, 'insufficient_heartbeats');
    return { ok: false, reason: 'suspicious_activity', strike };
  }

  // Passed all checks — credit the reward inside a transaction.
  const creditTx = db.transaction(() => {
    db.prepare(`UPDATE ad_sessions SET status = 'verified' WHERE id = ?`).run(session.id);

    const user = db.prepare(`SELECT balance FROM users WHERE telegram_id = ?`).get(telegramId);
    const newBalance = user.balance + rewardAmount;

    db.prepare(`UPDATE users SET balance = ?, updated_at = datetime('now') WHERE telegram_id = ?`)
      .run(newBalance, telegramId);

    db.prepare(`
      INSERT INTO transactions (telegram_id, type, amount, balance_after, meta)
      VALUES (?, 'ad_reward', ?, ?, ?)
    `).run(telegramId, rewardAmount, newBalance, JSON.stringify({ sessionToken }));

    return newBalance;
  });

  const newBalance = creditTx();
  return { ok: true, newBalance, rewardAmount };
}

module.exports = { startSession, heartbeat, verifySession };
