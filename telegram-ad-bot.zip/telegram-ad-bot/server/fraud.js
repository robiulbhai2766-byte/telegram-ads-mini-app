// server/fraud.js
// Multi-account prevention + strike/ban system.
//
// IMPORTANT HONESTY NOTE (read this before you ship):
// No server-side check can PERFECTLY stop a determined attacker who resets
// device IDs, uses proxies/VPNs, or farms SIM cards. This module raises the
// cost of cheating a lot (blocks the lazy 95% of abuse) but you should treat
// it as fraud-scoring / risk-signal infrastructure, not an unbeatable wall.
// Combine it with manual review of your top-earning accounts before payout.

const db = require('./db');

const MAX_ACCOUNTS_PER_IP_PER_DAY = parseInt(process.env.MAX_ACCOUNTS_PER_IP_PER_DAY || '3', 10);
const SUSPICION_STRIKES_BEFORE_BAN = parseInt(process.env.SUSPICION_STRIKES_BEFORE_BAN || '3', 10);

function getClientIp(req) {
  // Trust X-Forwarded-For only if you're behind a reverse proxy you control
  // (nginx/Cloudflare). Otherwise use req.socket.remoteAddress.
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return fwd.split(',')[0].trim();
  return req.socket.remoteAddress;
}

/**
 * Called once at registration / first login. Checks whether this device
 * fingerprint or IP is already tied to a DIFFERENT telegram account.
 * Returns { allowed: boolean, reason?: string }
 */
function checkDuplicateAccount({ telegramId, deviceHash, ip }) {
  if (!deviceHash) {
    // No fingerprint sent at all is itself suspicious (client tampering).
    return { allowed: false, reason: 'missing_device_fingerprint' };
  }

  // 1) Is this exact device hash already registered to a different user?
  const existingDevice = db.prepare(`
    SELECT DISTINCT telegram_id FROM device_fingerprints
    WHERE device_hash = ? AND telegram_id != ?
  `).all(deviceHash, telegramId);

  if (existingDevice.length > 0) {
    return { allowed: false, reason: 'duplicate_device' };
  }

  // 2) Is a banned fingerprint/IP trying to come back?
  const banned = db.prepare(`
    SELECT 1 FROM banned_fingerprints WHERE device_hash = ? OR ip_address = ? LIMIT 1
  `).get(deviceHash, ip);
  if (banned) {
    return { allowed: false, reason: 'banned_fingerprint' };
  }

  // 3) Too many distinct accounts from this IP in the last 24h? (soft signal —
  //    shared IPs from carriers/offices are common, so this flags rather than
  //    hard-blocks; see markSuspicious below for how it's used.)
  const recentFromIp = db.prepare(`
    SELECT COUNT(DISTINCT telegram_id) as cnt FROM device_fingerprints
    WHERE ip_address = ? AND created_at >= datetime('now', '-1 day') AND telegram_id != ?
  `).get(ip, telegramId);

  if (recentFromIp.cnt >= MAX_ACCOUNTS_PER_IP_PER_DAY) {
    return { allowed: false, reason: 'too_many_accounts_from_ip' };
  }

  return { allowed: true };
}

function recordFingerprint({ telegramId, deviceHash, ip }) {
  db.prepare(`
    INSERT INTO device_fingerprints (telegram_id, device_hash, ip_address)
    VALUES (?, ?, ?)
  `).run(telegramId, deviceHash, ip);

  db.prepare(`UPDATE users SET device_hash = ?, last_ip = ?, updated_at = datetime('now') WHERE telegram_id = ?`)
    .run(deviceHash, ip, telegramId);
}

/**
 * Adds a strike for suspicious behaviour (early ad verify, timer manipulation,
 * abnormal heartbeat pattern, etc). Auto-bans after threshold, and blacklists
 * the device/IP so the same hardware can't just make a fresh account.
 */
function markSuspicious(telegramId, reason) {
  const user = db.prepare(`SELECT * FROM users WHERE telegram_id = ?`).get(telegramId);
  if (!user) return;

  const strikes = user.suspicion_strikes + 1;

  if (strikes >= SUSPICION_STRIKES_BEFORE_BAN) {
    db.prepare(`
      UPDATE users SET suspicion_strikes = ?, is_banned = 1, ban_reason = ?, updated_at = datetime('now')
      WHERE telegram_id = ?
    `).run(strikes, reason, telegramId);

    db.prepare(`INSERT INTO banned_fingerprints (device_hash, ip_address, reason) VALUES (?, ?, ?)`)
      .run(user.device_hash, user.last_ip, `auto-ban after ${strikes} strikes: ${reason}`);

    return { banned: true, strikes };
  }

  db.prepare(`UPDATE users SET suspicion_strikes = ?, updated_at = datetime('now') WHERE telegram_id = ?`)
    .run(strikes, telegramId);

  return { banned: false, strikes };
}

function isBanned(telegramId) {
  const row = db.prepare(`SELECT is_banned FROM users WHERE telegram_id = ?`).get(telegramId);
  return !!row && row.is_banned === 1;
}

module.exports = { getClientIp, checkDuplicateAccount, recordFingerprint, markSuspicious, isBanned };
