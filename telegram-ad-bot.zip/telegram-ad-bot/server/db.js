// server/db.js
// SQLite schema + connection. Swap to `pg` (PostgreSQL) later by re-implementing
// the same function signatures in a db-postgres.js and changing this import.

const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id       TEXT UNIQUE NOT NULL,
  username          TEXT,
  first_name        TEXT,
  device_hash       TEXT,
  last_ip           TEXT,
  referred_by       TEXT,               -- telegram_id of referrer, nullable
  balance           REAL NOT NULL DEFAULT 0,
  is_banned         INTEGER NOT NULL DEFAULT 0,
  ban_reason        TEXT,
  suspicion_strikes INTEGER NOT NULL DEFAULT 0,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Every device fingerprint / IP combo ever seen for a telegram_id.
-- Used to detect the same physical device/IP registering multiple accounts.
CREATE TABLE IF NOT EXISTS device_fingerprints (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id  TEXT NOT NULL,
  device_hash  TEXT NOT NULL,
  ip_address   TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_fp_device ON device_fingerprints(device_hash);
CREATE INDEX IF NOT EXISTS idx_fp_ip ON device_fingerprints(ip_address);

CREATE TABLE IF NOT EXISTS banned_fingerprints (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  device_hash  TEXT,
  ip_address   TEXT,
  reason       TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- One row per ad-watch attempt. started_at is set by the SERVER, never trusted
-- from the client. verify() re-reads this row and compares wall-clock time.
CREATE TABLE IF NOT EXISTS ad_sessions (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id       TEXT NOT NULL,
  session_token     TEXT UNIQUE NOT NULL,
  ad_unit_id        TEXT,
  required_seconds  INTEGER NOT NULL,
  started_at        TEXT NOT NULL DEFAULT (datetime('now')),
  heartbeat_count   INTEGER NOT NULL DEFAULT 0,
  last_heartbeat_at TEXT,
  status            TEXT NOT NULL DEFAULT 'pending', -- pending | verified | rejected | expired
  ip_address        TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ad_token ON ad_sessions(session_token);

CREATE TABLE IF NOT EXISTS referrals (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id    TEXT NOT NULL,
  referred_id    TEXT UNIQUE NOT NULL,
  status         TEXT NOT NULL DEFAULT 'pending', -- pending | completed | rejected
  reward_amount  REAL,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at   TEXT
);

CREATE TABLE IF NOT EXISTS transactions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id   TEXT NOT NULL,
  type          TEXT NOT NULL,      -- ad_reward | referral_bonus | withdrawal | adjustment
  amount        REAL NOT NULL,      -- negative for debits
  balance_after REAL NOT NULL,
  meta          TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id     TEXT NOT NULL,
  amount          REAL NOT NULL,
  method          TEXT NOT NULL,
  account_details TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected | paid
  admin_note      TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  processed_at    TEXT
);

-- Pending referral codes captured from /start payload before the user
-- has opened the Mini App and authenticated (see bot.js).
CREATE TABLE IF NOT EXISTS pending_referrals (
  telegram_id TEXT PRIMARY KEY,
  referrer_id TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

module.exports = db;
